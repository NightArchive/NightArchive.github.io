import subprocess
import sys
import shutil
import time
from colorama import init, Fore, Style
from tqdm import tqdm

init(autoreset=True)
INFO = Fore.GREEN + Style.BRIGHT
STEP = Fore.YELLOW + Style.BRIGHT
ERROR = Fore.RED + Style.BRIGHT
TITLE = Fore.CYAN + Style.BRIGHT
RESET = Style.RESET_ALL
PACKAGES = [
    "PyQt6",
    "PyQt6-sip",
    "aiohappyeyeballs",
    "aiohttp",
    "aiohttp_socks",
    "aiosignal",
    "asyncio",
    "attrs",
    "beautifulsoup4",
    "bs4",
    "certifi",
    "charset-normalizer",
    "colorama",
    "frozenlist",
    "idna",
    "multidict",
    "python-socks",
    "requests",
    "soupsieve",
    "termcolor",
    "tqdm",
    "urllib3",
    "yarl"
]
def check_pip():
    if shutil.which("pip") is None:
        return True
    return True
def run_pip_install(package: str, timeout: int = 300):
    cmd = [sys.executable, "-m", "pip", "install", package]
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout
        )
        return (proc.returncode == 0, proc.stdout, proc.stderr, proc.returncode)
    except subprocess.TimeoutExpired as e:
        return (False, "", f"Timeout after {timeout}s", 124)
    except Exception as e:
        return (False, "", str(e), 125)
def pretty_lines(text: str, max_lines: int = 8):
    if not text:
        return []
    lines = [ln for ln in text.splitlines() if ln.strip()]
    return lines[-max_lines:]
def main():
    total = len(PACKAGES)
    print(TITLE + "="*60)
    print(TITLE + "      PYTHON LIBRARY INSTALLER (neat output)")
    print(TITLE + "="*60 + RESET + "\n")
    print(INFO + "[INFO] Checking environment..." + RESET)
    print(INFO + f"[INFO] Python: {sys.executable}" + RESET)
    if not check_pip():
        print(ERROR + "[ERROR] pip not found. Aborting." + RESET)
        return
    print(INFO + "[INFO] Environment OK.\n" + RESET)
    print(INFO + "[INFO] Starting installation...\n" + RESET)
    successes = 0
    with tqdm(total=total, desc="Installing packages", ncols=78, leave=True) as bar:
        for pkg in PACKAGES:
            tqdm.write(STEP + f"Installing {pkg}..." + RESET)
            ok, out, err, code = run_pip_install(pkg)
            if ok:
                tqdm.write(INFO + f"[OK] Installed {pkg}" + RESET)
                successes += 1
            else:
                tqdm.write(ERROR + f"[ERROR] Failed to install {pkg} (exit {code})" + RESET)
                for line in pretty_lines(err, max_lines=6):
                    tqdm.write(ERROR + "  " + line + RESET)
                for line in pretty_lines(out, max_lines=4):
                    tqdm.write(ERROR + "  (out) " + line + RESET)
            bar.update(1)
            time.sleep(0.05)
    print("\n" + TITLE + "="*60 + RESET)
    print(INFO + f"Installation finished: {successes}/{total} successful." + RESET)
    print(TITLE + "="*60 + RESET + "\n")
    input("Press Enter to exit...")
if __name__ == "__main__":
    main()

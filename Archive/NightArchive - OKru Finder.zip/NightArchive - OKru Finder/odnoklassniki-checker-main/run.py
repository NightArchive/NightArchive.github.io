#! /usr/bin/env python3
from odnoklassniki_checker import cli

if __name__ == "__main__":
    cli.run()

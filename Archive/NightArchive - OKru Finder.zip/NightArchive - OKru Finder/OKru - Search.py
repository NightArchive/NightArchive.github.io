"""
OKru Finder - BY NIGHTARCHIVE
BASED ON https://github.com/OSINT-mindset/odnoklassniki-checker

для поиска профилей в одноклассниках
Author: NightArchive
Email: NightArchiveHelp@gmail.com
GitHub: https://github.com/NightArchive
Telegram: @NightArchiveTg
"""
import sys
import os
import csv
import json
import asyncio
import logging
from pathlib import Path
from typing import List, Optional
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QFileDialog, QMessageBox, QTabWidget, QTextEdit, QComboBox,
    QSpinBox, QCheckBox, QProgressBar, QDialog, QFormLayout
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize, QSettings, QPoint, QRect
from PyQt6.QtGui import QFont, QIcon, QColor, QPixmap, QMouseEvent
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'odnoklassniki-checker-main'))
try:
    from odnoklassniki_checker.core import Processor, InputData, OutputData
except ImportError:
    Processor = None
    InputData = None
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
class WorkerThread(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(list)
    error = pyqtSignal(str)

    def __init__(self, targets: List[str], use_proxy: bool = False, proxy_url: str = ""):
        super().__init__()
        self.targets = targets
        self.use_proxy = use_proxy
        self.proxy_url = proxy_url
        self.processor = None
    def run(self):
        loop = None
        try:
            if sys.platform == 'win32':
                try:
                    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
                except (RuntimeError, DeprecationWarning):
                    pass
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            results = loop.run_until_complete(self._process_targets())
            self.finished.emit(results)
            
        except Exception as e:
            logger.error(f"Ошибка: {str(e)}", exc_info=True)
            self.error.emit(str(e))
        finally:
            if loop:
                try:
                    loop.close()
                except:
                    pass
    async def _process_targets(self):
        kwargs = {'no_progressbar': True}
        if self.use_proxy and self.proxy_url:
            kwargs['proxy'] = self.proxy_url   
        self.processor = Processor(**kwargs)
        input_data = [InputData(target) for target in self.targets]
        results = await self.processor.process(input_data)
        await self.processor.close()
        return results
class MacOSStyleTitleBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(28)
        self.setStyleSheet("""
            QWidget {
                background-color: #f5f5f7;
                border-bottom: 1px solid #e0e0e0;
            }
        """)
        layout = QHBoxLayout()
        layout.setContentsMargins(12, 0, 12, 0)
        layout.setSpacing(8)
        self.close_btn = self._create_traffic_light_button("#ff3b30")
        self.minimize_btn = self._create_traffic_light_button("#ffcc00")
        self.maximize_btn = self._create_traffic_light_button("#34c759") 
        layout.addWidget(self.close_btn)
        layout.addWidget(self.minimize_btn)
        layout.addWidget(self.maximize_btn)
        layout.addStretch()
        self.title_label = QLabel("OKru Finder")
        title_font = QFont()
        title_font.setPointSize(11)
        title_font.setBold(True)
        self.title_label.setFont(title_font)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet("color: #1d1d1d;")
        layout.addWidget(self.title_label, 1)
        layout.addStretch()
        self.setLayout(layout)
        self.drag_position = None
    
    def _create_traffic_light_button(self, color):
        btn = QPushButton()
        btn.setFixedSize(12, 12)
        btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {color};
                border: none;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: {color};
                opacity: 0.8;
            }}
        """)
        return btn
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.window().frameGeometry().topLeft()
            event.accept()
    def mouseMoveEvent(self, event: QMouseEvent):
        if self.drag_position is not None and event.buttons() == Qt.MouseButton.LeftButton:
            self.window().move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("")
        self.setModal(True)
        self.setMinimumWidth(550)
        self.setMinimumHeight(480)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setStyleSheet(self._get_macos_stylesheet())
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        self.title_bar = MacOSStyleTitleBar(self)
        self.title_bar.close_btn.clicked.connect(self.reject)
        self.title_bar.minimize_btn.clicked.connect(self.showMinimized)
        self.title_bar.maximize_btn.clicked.connect(self._toggle_maximize)
        main_layout.addWidget(self.title_bar)
        layout = QVBoxLayout()
        title = QLabel("OKru Finder")
        title_font = QFont()
        title_font.setPointSize(28)
        title_font.setBold(True)
        title.setFont(title_font)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        subtitle = QLabel("Профессиональный поиск профилей в Одноклассниках")
        subtitle_font = QFont()
        subtitle_font.setPointSize(12)
        subtitle.setFont(subtitle_font)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #666666;")
        layout.addWidget(subtitle)
        layout.addSpacing(30)
        info_label = QLabel("Информация о разработчике:")
        info_font = QFont()
        info_font.setPointSize(11)
        info_font.setBold(True)
        info_label.setFont(info_font)
        layout.addWidget(info_label)
        form_layout = QFormLayout()
        github_label = QLabel("GitHub:")
        github_value = QLabel('<a href="https://github.com/NightArchive" style="color: #00bfff;">NightArchive</a>')
        github_value.setOpenExternalLinks(True)
        form_layout.addRow(github_label, github_value)
        email_label = QLabel("Telegram:")
        email_value = QLabel('<a href="https://t.me/NightArchiveTg" style="color: #00bfff;">t.me/NightArchiveTg</a>')
        email_value.setOpenExternalLinks(True)
        form_layout.addRow(email_label, email_value)
        version_label = QLabel("Версия:")
        version_value = QLabel("1.0.0")
        form_layout.addRow(version_label, version_value)
        layout.addLayout(form_layout)
        layout.addSpacing(30)
        login_button = QPushButton("Войти в приложение")
        login_button.setMinimumHeight(44)
        login_font = QFont()
        login_font.setPointSize(13)
        login_font.setBold(True)
        login_button.setFont(login_font)
        login_button.setCursor(Qt.CursorShape.PointingHandCursor)
        login_button.setStyleSheet("""
            QPushButton {
                background-color: #0a84ff;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0a73e0;
            }
            QPushButton:pressed {
                background-color: #0962c4;
            }
        """)
        login_button.clicked.connect(self.accept)
        layout.addWidget(login_button)
        layout.setContentsMargins(30, 20, 30, 30)
        main_layout.addLayout(layout, 1)
        self.setLayout(main_layout)
        self.is_maximized = False
    def _toggle_maximize(self):
        if self.is_maximized:
            self.showNormal()
            self.is_maximized = False
        else:
            self.showMaximized()
            self.is_maximized = True
    def _get_macos_stylesheet(self):
        return """
            QDialog {
                background-color: #f5f5f7;
                color: #1d1d1d;
            }
            QLabel {
                color: #1d1d1d;
            }
            QLineEdit {
                background-color: #ffffff;
                color: #1d1d1d;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 2px solid #0a84ff;
                padding: 7px 11px;
            }
        """
class OKruFinderApp(QMainWindow):
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("")
        self.setMinimumSize(1200, 750)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setStyleSheet(self._get_macos_stylesheet())
        self.results = []
        self.worker = None
        self.is_maximized = False
        self._create_custom_title_bar()
        self._create_ui()
        self._load_settings()
    def _create_custom_title_bar(self):
        self.title_bar = MacOSStyleTitleBar(self)
        self.title_bar.title_label.setText("OKru Finder")
        self.title_bar.close_btn.clicked.connect(self.close)
        self.title_bar.minimize_btn.clicked.connect(self.showMinimized)
        self.title_bar.maximize_btn.clicked.connect(self._toggle_maximize)
    def _toggle_maximize(self):
        if self.is_maximized:
            self.showNormal()
            self.is_maximized = False
        else:
            self.showMaximized()
            self.is_maximized = True
    def _create_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        main_layout.addWidget(self.title_bar)
        content_layout = QVBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        tabs = QTabWidget()
        search_widget = self._create_search_tab()
        tabs.addTab(search_widget, "🔍 Поиск")
        results_widget = self._create_results_tab()
        tabs.addTab(results_widget, "📊 Результаты")
        settings_widget = self._create_settings_tab()
        tabs.addTab(settings_widget, "⚙️ Параметры")
        logs_widget = self._create_logs_tab()
        tabs.addTab(logs_widget, "📋 Логи")
        content_layout.addWidget(tabs)
        main_layout.addLayout(content_layout, 1)
        central_widget.setLayout(main_layout)
        self.statusBar().showMessage("Готово к работе")
    def _create_search_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(12)
        title = QLabel("Поиск профилей")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        input_label = QLabel("Введите данные для поиска")
        input_label.setStyleSheet("font-size: 11px; color: #a0a0a0;")
        layout.addWidget(input_label)
        self.input_text = QTextEdit()
        self.input_text.setPlaceholderText("Один адрес на строку\n\nПримеры:\nuser@gmail.com\n+79001234567\nusername")
        self.input_text.setMinimumHeight(180)
        self.input_text.setMaximumHeight(280)
        self.input_text.setStyleSheet("""
            QTextEdit {
                background-color: #ffffff;
                color: #1d1d1d;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                padding: 10px;
                font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
                font-size: 12px;
            }
            QTextEdit:focus {
                border: 2px solid #0a84ff;
                padding: 9px;
            }
        """)
        layout.addWidget(self.input_text)
        self.input_text.textChanged.connect(self._update_line_counter)
        self.line_counter = QLabel("0 строк")
        self.line_counter.setStyleSheet("font-size: 10px; color: #707070;")
        layout.addWidget(self.line_counter)   
        layout.addSpacing(8)
        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(8)
        load_button = QPushButton("Загрузить файл")
        load_button.setMinimumHeight(36)
        load_button.clicked.connect(self._load_file)
        load_button.setStyleSheet(self._get_secondary_button_style())
        load_button.setCursor(Qt.CursorShape.PointingHandCursor)
        buttons_layout.addWidget(load_button)
        paste_button = QPushButton("Вставить")
        paste_button.setMinimumHeight(36)
        paste_button.clicked.connect(self._paste_from_clipboard)
        paste_button.setStyleSheet(self._get_secondary_button_style())
        paste_button.setCursor(Qt.CursorShape.PointingHandCursor)
        buttons_layout.addWidget(paste_button)
        clear_button = QPushButton("Очистить")
        clear_button.setMinimumHeight(36)
        clear_button.clicked.connect(lambda: self.input_text.clear())
        clear_button.setStyleSheet(self._get_secondary_button_style())
        clear_button.setCursor(Qt.CursorShape.PointingHandCursor)
        buttons_layout.addWidget(clear_button)
        layout.addLayout(buttons_layout)
        layout.addSpacing(12)
        status_layout = QHBoxLayout()
        status_layout.setSpacing(8)
        self.status_icon = QLabel("○")
        self.status_icon.setStyleSheet("font-size: 12px; color: #999999;")
        status_layout.addWidget(self.status_icon)
        self.status_label = QLabel("Готово")
        self.status_label.setStyleSheet("color: #666666; font-size: 12px;")
        status_layout.addWidget(self.status_label, 1)
        layout.addLayout(status_layout)
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setMinimumHeight(3)
        self.progress_bar.setMaximumHeight(3)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #e5e5e7;
                border: none;
                border-radius: 2px;
                text-align: center;
                padding: 0px;
            }
            QProgressBar::chunk {
                background-color: #0a84ff;
                border-radius: 2px;
            }
        """)
        layout.addWidget(self.progress_bar)
        layout.addSpacing(12)
        start_button = QPushButton("Начать поиск")
        start_button.setMinimumHeight(44)
        start_font = QFont()
        start_font.setPointSize(11)
        start_font.setBold(True)
        start_button.setFont(start_font)
        start_button.setCursor(Qt.CursorShape.PointingHandCursor)
        start_button.setStyleSheet("""
            QPushButton {
                background-color: #0a84ff;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #0a73e0;
            }
            QPushButton:pressed {
                background-color: #0962c4;
            }
        """)
        start_button.clicked.connect(self._start_search)
        layout.addWidget(start_button)
        layout.addStretch()
        widget.setLayout(layout)
        return widget
    def _create_results_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        title = QLabel("Результаты поиска")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(7)
        self.results_table.setHorizontalHeaderLabels([
            "Запрос", "Статус", "Имя", "Email", "Телефон", "Профиль", "Зарегистрирован"
        ])
        self.results_table.setAlternatingRowColors(True)
        self.results_table.setStyleSheet("""
            QTableWidget {
                background-color: #2d2d2d;
                color: #ffffff;
                gridline-color: #404040;
            }
            QHeaderView::section {
                background-color: #3d3d3d;
                color: #ffffff;
                padding: 5px;
                border: none;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QTableWidget::item:selected {
                background-color: #0066cc;
            }
        """)
        layout.addWidget(self.results_table)
        export_layout = QHBoxLayout()
        export_csv = QPushButton("💾 Экспортировать CSV")
        export_csv.clicked.connect(self._export_csv)
        export_layout.addWidget(export_csv)       
        export_json = QPushButton("💾 Экспортировать JSON")
        export_json.clicked.connect(self._export_json)
        export_layout.addWidget(export_json)        
        clear_results = QPushButton("🗑️ Очистить результаты")
        clear_results.clicked.connect(self._clear_results)
        export_layout.addWidget(clear_results)       
        layout.addLayout(export_layout)        
        widget.setLayout(layout)
        return widget
    def _create_settings_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        title = QLabel("Параметры поиска")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        form_layout = QFormLayout()
        self.use_proxy_check = QCheckBox("Использовать прокси")
        form_layout.addRow("Прокси:", self.use_proxy_check)       
        self.proxy_url = QLineEdit()
        self.proxy_url.setPlaceholderText("socks5://127.0.0.1:9050")
        form_layout.addRow("URL прокси:", self.proxy_url)
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setValue(30)
        self.timeout_spin.setMinimum(1)
        self.timeout_spin.setMaximum(300)
        form_layout.addRow("Таймаут (сек):", self.timeout_spin)
        self.threads_spin = QSpinBox()
        self.threads_spin.setValue(5)
        self.threads_spin.setMinimum(1)
        self.threads_spin.setMaximum(50)
        form_layout.addRow("Параллельные запросы:", self.threads_spin)   
        layout.addLayout(form_layout)
        layout.addSpacing(20)
        info_box = QLabel(
            "OKru Finder v1.0\n\n"
            "Профессиональный инструмент для поиска профилей в Одноклассниках.\n\n"
            "Разработчик: NightArchive\n"
            "Email: NightArchiveHelp@gmail.com\n"
            "GitHub: https://github.com/NightArchive\n\n"
            "Внимание: используйте инструмент только в законных целях."
        )
        info_box.setWordWrap(True)
        info_box.setStyleSheet("border: 1px solid #404040; padding: 10px; border-radius: 5px;")
        layout.addWidget(info_box)
        layout.addStretch()
        widget.setLayout(layout)
        return widget
    def _create_logs_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        title = QLabel("Логи и отладка")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        self.logs_text = QTextEdit()
        self.logs_text.setReadOnly(True)
        self.logs_text.setStyleSheet("""
            QTextEdit {
                background-color: #f5f5f7;
                color: #1d1d1d;
                font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
                font-size: 11px;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
            }
        """)
        layout.addWidget(self.logs_text)
        button_layout = QHBoxLayout()
        clear_logs = QPushButton("🗑️ Очистить логи")
        clear_logs.clicked.connect(lambda: self.logs_text.clear())
        button_layout.addWidget(clear_logs)
        copy_logs = QPushButton("📋 Копировать")
        copy_logs.clicked.connect(lambda: QApplication.clipboard().setText(self.logs_text.toPlainText()))
        button_layout.addWidget(copy_logs)
        layout.addLayout(button_layout)
        
        widget.setLayout(layout)
        return widget
    def _update_line_counter(self):
        text = self.input_text.toPlainText()
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        count = len(lines)
        self.line_counter.setText(f"{count} строк" if count != 0 else "0 строк")
    def _insert_template(self, template_text):
        self.input_text.setText(template_text)
        self.input_text.setFocus()
    def _paste_from_clipboard(self):
        clipboard = QApplication.clipboard()
        text = clipboard.text()
        if text:
            self.input_text.setText(text)
            self._log("Данные вставлены из буфера обмена")
        else:
            QMessageBox.warning(self, "Ошибка", "Буфер обмена пуст")
    def _load_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Выберите файл", "", "Text Files (*.txt);;CSV Files (*.csv);;All Files (*)"
        )
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.input_text.setText(content)
                self._log(f"✅ Файл загружен: {file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить файл: {e}")
    def _start_search(self):
        targets = [line.strip() for line in self.input_text.toPlainText().split('\n') if line.strip()]
        if not targets:
            QMessageBox.warning(self, "Ошибка", "Введите данные для поиска")
            return
        if not Processor:
            QMessageBox.critical(self, "Ошибка", "Модуль не установлен.\npip install -r requirements_gui.txt")
            return
        self.status_icon.setText("●")
        self.status_icon.setStyleSheet("font-size: 12px; color: #ff9500;")
        self.status_label.setText(f"Поиск...")
        self.status_label.setStyleSheet("color: #ff9500; font-size: 12px;")
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setMaximum(len(targets))
        self._log(f"Начат поиск {len(targets)} целей")
        self.statusBar().showMessage(f"Поиск: {len(targets)} целей")
        self.worker = WorkerThread(
            targets,
            self.use_proxy_check.isChecked(),
            self.proxy_url.text()
        )
        self.worker.finished.connect(self._on_search_finished)
        self.worker.error.connect(self._on_search_error)
        self.worker.start()
    def _on_search_finished(self, results):
        found_count = sum(len(r.results) for r in results)   
        self._log(f"Поиск завершен: найдено {found_count} профилей")
        self.status_icon.setText("●")
        self.status_icon.setStyleSheet("font-size: 12px; color: #0a84ff;")
        self.status_label.setText(f"Готово ({found_count} найдено)")
        self.status_label.setStyleSheet("color: #0a84ff; font-size: 12px;")
        self.progress_bar.setVisible(False)
        self.statusBar().showMessage(f"Готово: {found_count} профилей")
        self.results_table.setRowCount(0)
        row = 0
        for result_list in results:
            for result in result_list.results:
                self.results_table.insertRow(row)
                self.results_table.setItem(row, 0, QTableWidgetItem(str(result_list.input_data)))
                self.results_table.setItem(row, 1, QTableWidgetItem(str(result.code) if result.code else "N/A"))
                self.results_table.setItem(row, 2, QTableWidgetItem(result.masked_name or ""))
                self.results_table.setItem(row, 3, QTableWidgetItem(result.masked_email or ""))
                self.results_table.setItem(row, 4, QTableWidgetItem(result.masked_phone or ""))
                self.results_table.setItem(row, 5, QTableWidgetItem(result.profile_info or ""))
                self.results_table.setItem(row, 6, QTableWidgetItem(result.profile_registred or ""))  
                row += 1
        self.results_table.resizeColumnsToContents()
    def _on_search_error(self, error_msg):
        self._log(f"Ошибка: {error_msg}")
        self.status_icon.setText("●")
        self.status_icon.setStyleSheet("font-size: 12px; color: #ff3b30;")
        self.status_label.setText("Ошибка")
        self.status_label.setStyleSheet("color: #ff3b30; font-size: 12px;")
        self.progress_bar.setVisible(False)
        self.statusBar().showMessage("Ошибка при поиске")
        QMessageBox.critical(self, "Ошибка", f"{error_msg}")
    def _export_csv(self):
        if self.results_table.rowCount() == 0:
            QMessageBox.warning(self, "Ошибка", "Нет результатов для экспорта")
            return
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить как CSV", f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv", "CSV Files (*.csv)"
        )
        if file_path:
            try:
                with open(file_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    headers = []
                    for col in range(self.results_table.columnCount()):
                        headers.append(self.results_table.horizontalHeaderItem(col).text())
                    writer.writerow(headers)
                    for row in range(self.results_table.rowCount()):
                        row_data = []
                        for col in range(self.results_table.columnCount()):
                            item = self.results_table.item(row, col)
                            row_data.append(item.text() if item else "")
                        writer.writerow(row_data)
                self._log(f"✅ Результаты экспортированы в CSV: {file_path}")
                QMessageBox.information(self, "Успех", f"Результаты сохранены в:\n{file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось экспортировать: {e}")
    def _export_json(self):
        if self.results_table.rowCount() == 0:
            QMessageBox.warning(self, "Ошибка", "Нет результатов для экспорта")
            return
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить как JSON", f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json", "JSON Files (*.json)"
        )
        if file_path:
            try:
                data = []
                headers = []
                for col in range(self.results_table.columnCount()):
                    headers.append(self.results_table.horizontalHeaderItem(col).text())
                
                for row in range(self.results_table.rowCount()):
                    row_data = {}
                    for col in range(self.results_table.columnCount()):
                        item = self.results_table.item(row, col)
                        row_data[headers[col]] = item.text() if item else ""
                    data.append(row_data)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                
                self._log(f"✅ Результаты экспортированы в JSON: {file_path}")
                QMessageBox.information(self, "Успех", f"Результаты сохранены в:\n{file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось экспортировать: {e}")
    def _clear_results(self):
        reply = QMessageBox.question(self, "Подтверждение", "Очистить все результаты?")
        if reply == QMessageBox.StandardButton.Yes:
            self.results_table.setRowCount(0)
            self._log("Результаты очищены")
    def _log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {message}"
        self.logs_text.append(log_message)
        logger.info(message)
    def _load_settings(self):
        settings = QSettings("NightArchive", "OKruFinder")
    def _get_secondary_button_style(self):
        return """
            QPushButton {
                background-color: #e5e5e7;
                color: #1d1d1d;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #d0d0d2;
            }
            QPushButton:pressed {
                background-color: #a1a1a6;
            }
        """
    def _get_macos_stylesheet(self):
        return """
            QMainWindow {
                background-color: #f5f5f7;
                color: #1d1d1d;
            }
            QWidget {
                background-color: #f5f5f7;
                color: #1d1d1d;
            }
            QTabWidget::pane {
                border: none;
                background-color: #f5f5f7;
            }
            QTabBar {
                background-color: #f5f5f7;
                border-bottom: 1px solid #e0e0e0;
            }
            QTabBar::tab {
                background-color: transparent;
                color: #1d1d1d;
                padding: 10px 20px;
                border: none;
                border-bottom: 2px solid transparent;
                font-size: 13px;
                font-weight: 500;
            }
            QTabBar::tab:hover {
                color: #0a84ff;
            }
            QTabBar::tab:selected {
                border-bottom: 2px solid #0a84ff;
                color: #0a84ff;
            }
            QPushButton {
                background-color: #e5e5e7;
                color: #1d1d1d;
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: 500;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #d0d0d2;
            }
            QPushButton:pressed {
                background-color: #a1a1a6;
            }
            QLineEdit, QTextEdit, QComboBox {
                background-color: #ffffff;
                color: #1d1d1d;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 13px;
                selection-background-color: #0a84ff;
                selection-color: #ffffff;
            }
            QLineEdit:focus, QTextEdit:focus, QComboBox:focus {
                border: 2px solid #0a84ff;
                padding: 7px 11px;
            }
            QLabel {
                color: #1d1d1d;
            }
            QProgressBar {
                background-color: #e5e5e7;
                border: none;
                border-radius: 3px;
                text-align: center;
                color: #1d1d1d;
                height: 4px;
            }
            QProgressBar::chunk {
                background-color: #0a84ff;
                border-radius: 2px;
            }
            QTableWidget {
                background-color: #ffffff;
                color: #1d1d1d;
                gridline-color: #e0e0e0;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
            }
            QHeaderView::section {
                background-color: #f9f9f9;
                color: #1d1d1d;
                padding: 8px;
                border: none;
                border-bottom: 1px solid #e0e0e0;
                font-weight: 600;
                font-size: 13px;
            }
            QTableWidget::item {
                padding: 6px;
                border: none;
                border-bottom: 1px solid #f0f0f0;
            }
            QTableWidget::item:selected {
                background-color: #0a84ff;
                color: #ffffff;
            }
            QCheckBox {
                color: #1d1d1d;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
            }
            QCheckBox::indicator:unchecked {
                background-color: #e5e5e7;
                border: none;
                border-radius: 4px;
            }
            QCheckBox::indicator:checked {
                background-color: #0a84ff;
                border: none;
                border-radius: 4px;
            }
            QSpinBox {
                background-color: #ffffff;
                color: #1d1d1d;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                padding: 6px 8px;
                font-size: 13px;
            }
            QSpinBox:focus {
                border: 2px solid #0a84ff;
                padding: 5px 7px;
            }
            QStatusBar {
                background-color: #f5f5f7;
                color: #1d1d1d;
                border-top: 1px solid #e0e0e0;
                font-size: 12px;
                padding: 4px;
            } """
def main():
    app = QApplication(sys.argv)
    login_dialog = LoginDialog()
    if login_dialog.exec() == QDialog.DialogCode.Accepted:
        window = OKruFinderApp()
        window.show()
        sys.exit(app.exec())
if __name__ == "__main__":
    main()
